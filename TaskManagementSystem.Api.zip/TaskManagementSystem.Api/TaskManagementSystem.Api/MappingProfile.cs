﻿using AutoMapper;
using TaskManagementSystem.Entities.Models;
using TaskManagementSystem.Shared.DataTransferObject;

namespace TaskManagementSystem.Api
{
    public class MappingProfile: Profile
    {
        public MappingProfile()
        {
            CreateMap<UserForRegistrationDto, User>();
            CreateMap<CreateBoardDto, Board>();
            CreateMap<Board, BoardDto>();
            CreateMap<CreateSwimlaneDto, Swimlane>();
            CreateMap<Swimlane, SwimlaneDto>();
            CreateMap<Board, BoardSwimlaneDto>()
                .ForCtorParam("swimlanes", opt => opt.MapFrom(b => b.Swimlanes));
            CreateMap<CreateCardDto, Card>();
            CreateMap<Card, CardDto>();
            CreateMap<CardDto, Card>()
                .ForMember(dest => dest.Assigne, opt => opt.Ignore())
                .ForMember(dest => dest.Swimlane, opt => opt.Ignore())
                .ForMember(dest => dest.History, opt => opt.Ignore());
        }
    }
}
