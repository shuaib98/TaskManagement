using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.Extensions.Logging;
using Serilog;
using TaskManagementSystem.Api.Extensions;
using TaskManagementSystem.Api.Handler;
using TaskManagementSystem.Presentation.ActionFilters;

var builder = WebApplication.CreateBuilder(args);

builder.AddRedisOutputCache("cache");
builder.AddServiceDefaults();

// Add services to the container.
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

builder.Services.AddAuthentication();

builder.Services.ConfigureCors();
builder.Services.ConfigureSqlContext(builder.Configuration);
builder.Services.ConfigureServiceManager();
builder.Services.AddAutoMapper(typeof(Program));
builder.Services.ConfigureIdentity();
builder.Services.ConfigureJWT(builder.Configuration);
builder.Services.AddJwtConfiguration(builder.Configuration);
builder.Services.AddScoped<ValidationFilter>();
builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
builder.Services.AddControllers().AddApplicationPart(typeof(TaskManagementSystem.Presentation.AssemblyReference).Assembly);

var app = builder.Build();

// Configure the HTTP request pipeline.
app.UseExceptionHandler(opt => { });
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}
app.UseCors("CorsPolicy");
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseForwardedHeaders(new ForwardedHeadersOptions
{
    ForwardedHeaders = ForwardedHeaders.All
});
app.UseAuthentication(); 
app.UseAuthorization();
app.UseOutputCache();
app.MapControllers();


await app.RunAsync();


