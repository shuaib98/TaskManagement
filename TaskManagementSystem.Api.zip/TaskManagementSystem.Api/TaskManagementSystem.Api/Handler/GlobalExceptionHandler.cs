﻿using Azure;
using Grpc.Core;
using Logger;
using Microsoft.AspNetCore.Diagnostics;
using TaskManagementSystem.Common;
using TaskManagementSystem.Common.Helpers;

namespace TaskManagementSystem.Api.Handler
{
    public class GlobalExceptionHandler(ILogger<GlobalExceptionHandler> _logger) : IExceptionHandler
    {
    
        public async ValueTask<bool> TryHandleAsync(HttpContext context, Exception exception, CancellationToken cancellationToken)
        {
            context.Response.ContentType = "application/json";

            var errorMessage = exception is TaskManagementException ? CreateErrorMessage(exception as TaskManagementException) : exception.Message;

            var contextFeature = context.Features.Get<IExceptionHandlerFeature>();
            if (contextFeature != null)
            {
              
                var response = new ErrorDetails
                {
                    Status = Status.Error,
                    Message = $"{errorMessage} {contextFeature.Error.Message}",
                };

                _logger.LogError(exception, $"An error occurred: {errorMessage}");

                await context.Response.WriteAsJsonAsync(response);
            }

            

            return true;
        }

        private string CreateErrorMessage(TaskManagementException ex)
        {
            var errorType = ex.ErrorType.ToString();
            var translated = ResourceHelper.GetTranslatedText(errorType, "en");
            return string.Format(translated, ex.Args);
        }
    }
}
