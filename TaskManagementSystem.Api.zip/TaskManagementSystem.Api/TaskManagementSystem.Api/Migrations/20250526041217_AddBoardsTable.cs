﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TaskManagementSystem.Api.Migrations
{
    /// <inheritdoc />
    public partial class AddBoardsTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BoardUsers_Board_BoardsId",
                table: "BoardUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_Card_AspNetUsers_AssigneId",
                table: "Card");

            migrationBuilder.DropForeignKey(
                name: "FK_Card_Swimlane_SwimlaneId",
                table: "Card");

            migrationBuilder.DropForeignKey(
                name: "FK_CardHistory_AspNetUsers_ChangedByUserId",
                table: "CardHistory");

            migrationBuilder.DropForeignKey(
                name: "FK_CardHistory_Card_CardId",
                table: "CardHistory");

            migrationBuilder.DropForeignKey(
                name: "FK_Swimlane_Board_BoardId",
                table: "Swimlane");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Swimlane",
                table: "Swimlane");

            migrationBuilder.DropPrimaryKey(
                name: "PK_CardHistory",
                table: "CardHistory");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Card",
                table: "Card");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Board",
                table: "Board");

            migrationBuilder.RenameTable(
                name: "Swimlane",
                newName: "Swimlanes");

            migrationBuilder.RenameTable(
                name: "CardHistory",
                newName: "CardHistories");

            migrationBuilder.RenameTable(
                name: "Card",
                newName: "Cards");

            migrationBuilder.RenameTable(
                name: "Board",
                newName: "Boards");

            migrationBuilder.RenameIndex(
                name: "IX_Swimlane_BoardId",
                table: "Swimlanes",
                newName: "IX_Swimlanes_BoardId");

            migrationBuilder.RenameIndex(
                name: "IX_CardHistory_ChangedByUserId",
                table: "CardHistories",
                newName: "IX_CardHistories_ChangedByUserId");

            migrationBuilder.RenameIndex(
                name: "IX_CardHistory_CardId",
                table: "CardHistories",
                newName: "IX_CardHistories_CardId");

            migrationBuilder.RenameIndex(
                name: "IX_Card_SwimlaneId",
                table: "Cards",
                newName: "IX_Cards_SwimlaneId");

            migrationBuilder.RenameIndex(
                name: "IX_Card_AssigneId",
                table: "Cards",
                newName: "IX_Cards_AssigneId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Swimlanes",
                table: "Swimlanes",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_CardHistories",
                table: "CardHistories",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Cards",
                table: "Cards",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Boards",
                table: "Boards",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_BoardUsers_Boards_BoardsId",
                table: "BoardUsers",
                column: "BoardsId",
                principalTable: "Boards",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_CardHistories_AspNetUsers_ChangedByUserId",
                table: "CardHistories",
                column: "ChangedByUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "FK_CardHistories_Cards_CardId",
                table: "CardHistories",
                column: "CardId",
                principalTable: "Cards",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Cards_AspNetUsers_AssigneId",
                table: "Cards",
                column: "AssigneId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "FK_Cards_Swimlanes_SwimlaneId",
                table: "Cards",
                column: "SwimlaneId",
                principalTable: "Swimlanes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Swimlanes_Boards_BoardId",
                table: "Swimlanes",
                column: "BoardId",
                principalTable: "Boards",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BoardUsers_Boards_BoardsId",
                table: "BoardUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_CardHistories_AspNetUsers_ChangedByUserId",
                table: "CardHistories");

            migrationBuilder.DropForeignKey(
                name: "FK_CardHistories_Cards_CardId",
                table: "CardHistories");

            migrationBuilder.DropForeignKey(
                name: "FK_Cards_AspNetUsers_AssigneId",
                table: "Cards");

            migrationBuilder.DropForeignKey(
                name: "FK_Cards_Swimlanes_SwimlaneId",
                table: "Cards");

            migrationBuilder.DropForeignKey(
                name: "FK_Swimlanes_Boards_BoardId",
                table: "Swimlanes");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Swimlanes",
                table: "Swimlanes");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Cards",
                table: "Cards");

            migrationBuilder.DropPrimaryKey(
                name: "PK_CardHistories",
                table: "CardHistories");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Boards",
                table: "Boards");

            migrationBuilder.RenameTable(
                name: "Swimlanes",
                newName: "Swimlane");

            migrationBuilder.RenameTable(
                name: "Cards",
                newName: "Card");

            migrationBuilder.RenameTable(
                name: "CardHistories",
                newName: "CardHistory");

            migrationBuilder.RenameTable(
                name: "Boards",
                newName: "Board");

            migrationBuilder.RenameIndex(
                name: "IX_Swimlanes_BoardId",
                table: "Swimlane",
                newName: "IX_Swimlane_BoardId");

            migrationBuilder.RenameIndex(
                name: "IX_Cards_SwimlaneId",
                table: "Card",
                newName: "IX_Card_SwimlaneId");

            migrationBuilder.RenameIndex(
                name: "IX_Cards_AssigneId",
                table: "Card",
                newName: "IX_Card_AssigneId");

            migrationBuilder.RenameIndex(
                name: "IX_CardHistories_ChangedByUserId",
                table: "CardHistory",
                newName: "IX_CardHistory_ChangedByUserId");

            migrationBuilder.RenameIndex(
                name: "IX_CardHistories_CardId",
                table: "CardHistory",
                newName: "IX_CardHistory_CardId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Swimlane",
                table: "Swimlane",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Card",
                table: "Card",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_CardHistory",
                table: "CardHistory",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Board",
                table: "Board",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_BoardUsers_Board_BoardsId",
                table: "BoardUsers",
                column: "BoardsId",
                principalTable: "Board",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Card_AspNetUsers_AssigneId",
                table: "Card",
                column: "AssigneId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "FK_Card_Swimlane_SwimlaneId",
                table: "Card",
                column: "SwimlaneId",
                principalTable: "Swimlane",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_CardHistory_AspNetUsers_ChangedByUserId",
                table: "CardHistory",
                column: "ChangedByUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "FK_CardHistory_Card_CardId",
                table: "CardHistory",
                column: "CardId",
                principalTable: "Card",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Swimlane_Board_BoardId",
                table: "Swimlane",
                column: "BoardId",
                principalTable: "Board",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
