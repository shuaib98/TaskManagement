﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TaskManagementSystem.Api.Migrations
{
    /// <inheritdoc />
    public partial class InitialData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BoardUser_AspNetUsers_UsersId",
                table: "BoardUser");

            migrationBuilder.DropForeignKey(
                name: "FK_BoardUser_Board_BoardsId",
                table: "BoardUser");

            migrationBuilder.DropForeignKey(
                name: "FK_Card_AspNetUsers_AssigneId",
                table: "Card");

            migrationBuilder.DropForeignKey(
                name: "FK_CardHistory_AspNetUsers_ChangedByUserId",
                table: "CardHistory");

            migrationBuilder.DropPrimaryKey(
                name: "PK_BoardUser",
                table: "BoardUser");

            migrationBuilder.RenameTable(
                name: "BoardUser",
                newName: "BoardUsers");

            migrationBuilder.RenameIndex(
                name: "IX_BoardUser_UsersId",
                table: "BoardUsers",
                newName: "IX_BoardUsers_UsersId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_BoardUsers",
                table: "BoardUsers",
                columns: new[] { "BoardsId", "UsersId" });

            migrationBuilder.AddForeignKey(
                name: "FK_BoardUsers_AspNetUsers_UsersId",
                table: "BoardUsers",
                column: "UsersId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_BoardUsers_Board_BoardsId",
                table: "BoardUsers",
                column: "BoardsId",
                principalTable: "Board",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Card_AspNetUsers_AssigneId",
                table: "Card",
                column: "AssigneId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "FK_CardHistory_AspNetUsers_ChangedByUserId",
                table: "CardHistory",
                column: "ChangedByUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.SetNull);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BoardUsers_AspNetUsers_UsersId",
                table: "BoardUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_BoardUsers_Board_BoardsId",
                table: "BoardUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_Card_AspNetUsers_AssigneId",
                table: "Card");

            migrationBuilder.DropForeignKey(
                name: "FK_CardHistory_AspNetUsers_ChangedByUserId",
                table: "CardHistory");

            migrationBuilder.DropPrimaryKey(
                name: "PK_BoardUsers",
                table: "BoardUsers");

            migrationBuilder.RenameTable(
                name: "BoardUsers",
                newName: "BoardUser");

            migrationBuilder.RenameIndex(
                name: "IX_BoardUsers_UsersId",
                table: "BoardUser",
                newName: "IX_BoardUser_UsersId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_BoardUser",
                table: "BoardUser",
                columns: new[] { "BoardsId", "UsersId" });

            migrationBuilder.AddForeignKey(
                name: "FK_BoardUser_AspNetUsers_UsersId",
                table: "BoardUser",
                column: "UsersId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_BoardUser_Board_BoardsId",
                table: "BoardUser",
                column: "BoardsId",
                principalTable: "Board",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Card_AspNetUsers_AssigneId",
                table: "Card",
                column: "AssigneId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_CardHistory_AspNetUsers_ChangedByUserId",
                table: "CardHistory",
                column: "ChangedByUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }
    }
}
