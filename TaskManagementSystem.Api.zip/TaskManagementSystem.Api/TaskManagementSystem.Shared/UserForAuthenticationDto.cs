﻿using System.ComponentModel.DataAnnotations;

namespace TaskManagementSystem.Shared
{
    public record UserForAuthenticationDto 
    {
        public string? Id { get; set; }
        [Required(ErrorMessage = "User name is required")] 
        public string? Email { get; init; } 

        [Required(ErrorMessage = "Password name is required")] 
        public string? Password { get; init; } 
    }
}
