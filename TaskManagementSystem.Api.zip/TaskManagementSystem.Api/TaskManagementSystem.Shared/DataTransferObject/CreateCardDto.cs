﻿namespace TaskManagementSystem.Shared.DataTransferObject
{
    public record CreateCardDto
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public int Order { get; set; }
        public string? AssigneeId { get; set; } = null;
        public string SwimlaneId { get; set; } = string.Empty;

    }
}
