﻿namespace TaskManagementSystem.Shared.DataTransferObject
{
    public record CreateBoardDto 
    {
        public string? Id { get; set; } 
        public string? Name { get; set; }
    }
}
