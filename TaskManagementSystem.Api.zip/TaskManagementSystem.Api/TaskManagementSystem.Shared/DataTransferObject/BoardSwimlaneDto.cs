﻿namespace TaskManagementSystem.Shared.DataTransferObject
{
    public record BoardSwimlaneDto(ICollection<SwimlaneDto> swimlanes) : BoardDto;
    
}
