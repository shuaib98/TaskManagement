﻿// Ignore Spelling: Swimlane Dto

namespace TaskManagementSystem.Shared.DataTransferObject
{
    public class CreateSwimlaneDto
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? BoardId { get; set; }
        public int Order { get; set; }
    }
}
