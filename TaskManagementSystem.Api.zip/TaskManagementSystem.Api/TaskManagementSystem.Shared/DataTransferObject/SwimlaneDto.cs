﻿namespace TaskManagementSystem.Shared.DataTransferObject
{
    public record SwimlaneDto(string Id,string Name,int Order,string BoardId,ICollection<CardDto> Cards);

}
