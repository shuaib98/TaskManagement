﻿namespace TaskManagementSystem.Shared.DataTransferObject;

    public record TokenDto(string AccessToken, string RefreshToken);

