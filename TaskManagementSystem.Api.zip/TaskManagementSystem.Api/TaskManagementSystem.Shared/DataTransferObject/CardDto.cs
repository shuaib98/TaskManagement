﻿namespace TaskManagementSystem.Shared.DataTransferObject
{
    public record CardDto(string Id,string Name,string Content,int Order,string swimlaneId);
}
