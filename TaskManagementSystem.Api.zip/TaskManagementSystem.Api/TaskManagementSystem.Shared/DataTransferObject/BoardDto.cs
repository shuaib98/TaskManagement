﻿namespace TaskManagementSystem.Shared.DataTransferObject
{
    public record BoardDto
    {
        public string? Id { get; init; }
        public string? Name { get; init; }
    }
}
