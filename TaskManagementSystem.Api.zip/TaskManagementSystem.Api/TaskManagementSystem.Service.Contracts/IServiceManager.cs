﻿namespace TaskManagementSystem.Service.Contracts
{
    public interface IServiceManager
    {
        IAuthenticationService AuthenticationService { get; }
        IBoardService BoardService { get; }

        ISwimlaneService SwimlaneService { get; }
        ICardService CardService { get; }
    }
}
