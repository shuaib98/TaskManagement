﻿using Microsoft.AspNetCore.Identity;
using TaskManagementSystem.Shared;
using TaskManagementSystem.Shared.DataTransferObject;

namespace TaskManagementSystem.Service.Contracts
{
    public interface IAuthenticationService
    {
        Task<IdentityResult> RegisterUser(UserForRegistrationDto userForRegistration);
        Task<bool> ValidateUser(UserForAuthenticationDto userForAuth); 
        Task<TokenDto> CreateToken(bool populateExp);
        Task<TokenDto> RefreshToken(TokenDto tokenDto);
    }
}
