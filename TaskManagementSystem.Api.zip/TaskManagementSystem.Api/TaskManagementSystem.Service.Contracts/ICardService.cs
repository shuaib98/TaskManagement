﻿using TaskManagementSystem.Shared.DataTransferObject;

namespace TaskManagementSystem.Service.Contracts
{
    public interface ICardService
    {
        Task<CardDto> InsertCardAsync(CreateCardDto card);
        Task<IEnumerable<CardDto>> UpdateCardSwimlaneAsync(IEnumerable<CardDto> cards);
    }
}
