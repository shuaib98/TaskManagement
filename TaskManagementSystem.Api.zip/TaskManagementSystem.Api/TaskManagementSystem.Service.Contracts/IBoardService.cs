﻿using TaskManagementSystem.Shared.DataTransferObject;

namespace TaskManagementSystem.Service.Contracts
{
    public interface IBoardService
    {
        Task<BoardDto> CreateBoard(CreateBoardDto createBoard, string emailId);
        Task<BoardDto> UpdateBoard(CreateBoardDto updateBoard);
        Task DeleteBoard(string boardId);
        Task<IEnumerable<BoardDto>> GetAllBoards();
        Task<BoardDto> GetBoardById(string boardId);
    }
}
