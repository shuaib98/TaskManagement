﻿// Ignore Spelling: Swimlane

using TaskManagementSystem.Shared.DataTransferObject;

namespace TaskManagementSystem.Service.Contracts
{
    public interface ISwimlaneService
    {
        Task<SwimlaneDto> CreateSwimlane(CreateSwimlaneDto swimlane);

        Task<IEnumerable<BoardSwimlaneDto>> GetSwimlineByBoardId(string boardId);
    }
}
