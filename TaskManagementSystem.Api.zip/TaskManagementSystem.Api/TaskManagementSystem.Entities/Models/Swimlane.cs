﻿namespace TaskManagementSystem.Entities.Models
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Collections.Generic;

    public class Swimlane
    {
        [Key]
        public string Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        [Required]
        public int Order { get; set; }

        [ForeignKey("Board")]
        public string BoardId { get; set; }

        public Board Board { get; set; }

        public ICollection<Card> Cards { get; set; } = new List<Card>();
    }
}
