﻿namespace TaskManagementSystem.Entities.Models
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class CardHistory
    {
        [Key]
        public string Id { get; set; }

        [Required]
        public string CardId { get; set; }

        [ForeignKey("CardId")]
        public Card Card { get; set; }

        [Required]
        public string Value { get; set; }

        public DateTime ChangedAt { get; set; } = DateTime.UtcNow;

        public string? ChangedByUserId { get; set; }

        [ForeignKey("ChangedByUserId")]
        public User ChangedBy { get; set; }
    }
}
