﻿

namespace TaskManagementSystem.Entities.Models
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class Card
    {
        [Key]
        public string Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        [Required]
        public string Content { get; set; }

        [Required]
        public int Order { get; set; }

        public string? AssigneId { get; set; }

        [ForeignKey("AssigneId")]
        public User Assigne { get; set; }

        [Required]
        public string SwimlaneId { get; set; }

        [ForeignKey("SwimlaneId")]
        public Swimlane Swimlane { get; set; }

        public ICollection<CardHistory> History { get; set; } = new List<CardHistory>();
    }
}
