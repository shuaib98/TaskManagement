﻿namespace TaskManagementSystem.Entities.Models
{
    using System.ComponentModel.DataAnnotations;
    using System.Collections.Generic;

    public class Board
    {
        [Key]
        public string Id { get; set; } 

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        public ICollection<User> Users { get; set; } = new List<User>();

        public ICollection<Swimlane> Swimlanes { get; set; } = new List<Swimlane>();
    }

}
