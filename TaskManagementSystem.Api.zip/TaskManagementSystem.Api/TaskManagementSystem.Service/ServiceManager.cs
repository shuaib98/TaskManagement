﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using TaskManagementSystem.DataAccessLayer.Contexts;
using TaskManagementSystem.Entities.ConfigurationModels;
using TaskManagementSystem.Entities.Models;
using TaskManagementSystem.Service.Contracts;
using TaskManagementSystem.Service.Decorator;

namespace TaskManagementSystem.Service
{
    public class ServiceManager : IServiceManager
    {
        private readonly Lazy<IAuthenticationService> _authenticationService;
        private readonly Lazy<IBoardService> _boardService;
        private readonly Lazy<ISwimlaneService> _swimlaneService;
        private readonly Lazy<ICardService> _cardService;


        public ServiceManager(
            IRepositoryManager repositoryManager, 
            IMapper mapper, 
            IOptions<JwtConfiguration> configuration,
            IMemoryCache memoryCache)
        {
            _authenticationService = 
                new Lazy<IAuthenticationService>(() => 
                    new AuthenticationService(mapper, repositoryManager, configuration, memoryCache));

            _boardService = new Lazy<IBoardService>(() => new BoardService(mapper,memoryCache,repositoryManager));
            _swimlaneService = new Lazy<ISwimlaneService>(() => new SwimlaneService(mapper, repositoryManager));
            _cardService = new Lazy<ICardService>(() => new CardService(repositoryManager, mapper));
        }

        public IAuthenticationService AuthenticationService => _authenticationService.Value;
        public IBoardService BoardService => _boardService.Value;
        public ISwimlaneService SwimlaneService => _swimlaneService.Value;
        public ICardService CardService => _cardService.Value;
    }
}
