﻿using AutoMapper;
using TaskManagementSystem.DataAccessLayer.Contexts;
using TaskManagementSystem.Entities.Models;
using TaskManagementSystem.Service.Contracts;
using TaskManagementSystem.Shared.DataTransferObject;

namespace TaskManagementSystem.Service
{
    public class SwimlaneService(IMapper mapper, IRepositoryManager repositoryManager) : ISwimlaneService
    {
        private readonly IMapper mapper = mapper;
        private readonly IRepositoryManager repositoryManager = repositoryManager;

        public async Task<SwimlaneDto>  CreateSwimlane(CreateSwimlaneDto swimlane)
        {
            swimlane.Id = Guid.NewGuid().ToString();
            var entity = mapper.Map<Swimlane>(swimlane);

            await repositoryManager.SwimlaneRepository.CreateSwimlane(entity);
            await repositoryManager.SaveAsync();
            var entityToReturn = mapper.Map<SwimlaneDto>(entity);
            return entityToReturn;
        }

        public async Task<IEnumerable<BoardSwimlaneDto>> GetSwimlineByBoardId(string boardId)
        {
            var result = await repositoryManager.SwimlaneRepository.GetSwimlineByBoardId(boardId);
            var listToResult = mapper.Map<IEnumerable<BoardSwimlaneDto>>(result);
            return listToResult;
        }
    }
}
