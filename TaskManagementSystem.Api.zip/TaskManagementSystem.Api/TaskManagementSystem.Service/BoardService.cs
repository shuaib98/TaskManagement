﻿using AutoMapper;
using Microsoft.Extensions.Caching.Memory;
using TaskManagementSystem.Common;
using TaskManagementSystem.Common.Enums;
using TaskManagementSystem.DataAccessLayer.Contexts;
using TaskManagementSystem.Entities.Models;
using TaskManagementSystem.Service.Contracts;
using TaskManagementSystem.Shared.DataTransferObject;

namespace TaskManagementSystem.Service
{
    public class BoardService(IMapper mapper, IMemoryCache memoryCache, IRepositoryManager repositoryManager) : IBoardService
    {
        

        public async Task<IEnumerable<BoardDto>> GetAllBoards()
        {

            var result = await repositoryManager.BoardRepository.GetAllBoards();

            var dtoEntity = mapper.Map<IEnumerable<BoardDto>>(result);
            return dtoEntity;
        }

        public async Task<BoardDto> CreateBoard(CreateBoardDto createBoard,string emailId)
        {
            var userId=string.Empty;
            if(!memoryCache.TryGetValue(emailId, out userId))
            {
                userId = await repositoryManager.UserRepository.GetUserIdByEmailAsync(emailId);
                memoryCache.Set(emailId, userId);
            }

            var user = await repositoryManager.UserRepository.FindByIdAsync(userId!);
            createBoard.Id = Guid.NewGuid().ToString();

            var boardEntity = mapper.Map<Board>(createBoard);
            boardEntity.Users.Add(user);
           
            await repositoryManager.BoardRepository.CreateBoard(boardEntity);
            await repositoryManager.SaveAsync();
            var boardToRetrun=mapper.Map<BoardDto>(boardEntity);
            return boardToRetrun;
        }

        public async Task<BoardDto> UpdateBoard(CreateBoardDto updateBoard)
        {
            var boardEntity = mapper.Map<Board>(updateBoard);
            await repositoryManager.BoardRepository.UpdateBoard(boardEntity);
            await repositoryManager.SaveAsync();
            var boardToRetrun = mapper.Map<BoardDto>(boardEntity);
            return boardToRetrun;
        }

        public async Task DeleteBoard(string boardId)
        {
            var board = await repositoryManager.BoardRepository.GetBoardById(boardId);
            await repositoryManager.BoardRepository.DeleteBoard(board);
            await repositoryManager.SaveAsync();
        }

        public async Task<BoardDto> GetBoardById(string boardId)
        {
            var boardEntity = await repositoryManager.BoardRepository.GetBoardById(boardId);
            if(boardEntity == null)
                throw new TaskManagementException(ExceptionEnum.BoardNotFound,"board not exits for provided id");

            var boardToRetrun = mapper.Map<BoardDto>(boardEntity);
            return boardToRetrun;
        }
    }
}
