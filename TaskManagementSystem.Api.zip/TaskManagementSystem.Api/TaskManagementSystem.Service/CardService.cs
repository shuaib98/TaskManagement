﻿using AutoMapper;
using TaskManagementSystem.DataAccessLayer.Contexts;
using TaskManagementSystem.Entities.Models;
using TaskManagementSystem.Service.Contracts;
using TaskManagementSystem.Shared.DataTransferObject;

namespace TaskManagementSystem.Service
{
    public class CardService(IRepositoryManager repositoryManager, IMapper mapper) : ICardService
    {
        private readonly IRepositoryManager repositoryManager = repositoryManager;

        public async Task<CardDto> InsertCardAsync(CreateCardDto card)
        {
            var entity = mapper.Map<Card>(card);
            entity.Id = Guid.NewGuid().ToString();
            await repositoryManager.CardRepository.InsertCardAsync(entity);
            await repositoryManager.SaveAsync();
            var entityToReturn = mapper.Map<CardDto>(entity);
            return entityToReturn;
        }

        public async Task<IEnumerable<CardDto>> UpdateCardSwimlaneAsync(IEnumerable<CardDto> cards)
        {
            var entities = mapper.Map<IEnumerable<Card>>(cards);
            repositoryManager.CardRepository.UpdateCardsSwimlaneAndOrder(entities);
            await repositoryManager.SaveAsync();
            return cards;
        }
    }
}
