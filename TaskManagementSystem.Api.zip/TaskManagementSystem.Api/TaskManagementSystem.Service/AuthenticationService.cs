﻿using AutoMapper;
using Entities.Exceptions;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using TaskManagementSystem.Common;
using TaskManagementSystem.Common.Enums;
using TaskManagementSystem.DataAccessLayer.Contexts;
using TaskManagementSystem.Entities.ConfigurationModels;
using TaskManagementSystem.Entities.Models;
using TaskManagementSystem.Service.Contracts;
using TaskManagementSystem.Shared;
using TaskManagementSystem.Shared.DataTransferObject;

namespace TaskManagementSystem.Service
{
    internal sealed class AuthenticationService(
        IMapper mapper, 
        IRepositoryManager repositoryManager, 
        IOptions<JwtConfiguration> configuration,
        IMemoryCache memoryCache) : IAuthenticationService
    {
        private readonly IMapper mapper = mapper;
        private readonly IOptions<JwtConfiguration> configuration = configuration;
        private readonly IRepositoryManager repositoryManager = repositoryManager;
       //private readonly UserManager<User> userManager;
        private User? _user;

        public async Task<IdentityResult> RegisterUser(UserForRegistrationDto userForRegistration)
        {
            var user = this.mapper.Map<User>(userForRegistration);
            var result = await this.repositoryManager.UserRepository.CreateAsync(user, userForRegistration?.Password!);
            if (result.Succeeded && userForRegistration?.Roles?.Count > 0)
                await this.repositoryManager.UserRepository.AddToRolesAsync(user, userForRegistration?.Roles!);

            return result;
        }
        public async Task<TokenDto> RefreshToken(TokenDto tokenDto)
        {
            var principal = GetPrincipalFromExpiredToken(tokenDto.AccessToken);
            var user = await this.repositoryManager.UserRepository.FindByNameAsync(principal?.Identity?.Name!);
            if (user == null || user.RefreshToken != tokenDto.RefreshToken || user.RefreshTokenExpiryTime <= DateTime.Now)
                throw new RefreshTokenBadRequest();

            this._user = user;
            return await CreateToken(populateExp: false);
        }

        public async Task<TokenDto> CreateToken(bool populateExp)
        {
            var signingCredentials = GetSigningCredentials(); 
            var claims = await GetClaims(); 
            var tokenOptions = GenerateTokenOptions(signingCredentials, claims);
            var refreshToken = GenerateRefreshToken(); 
            _user!.RefreshToken = refreshToken;
            if (populateExp)
                _user.RefreshTokenExpiryTime = DateTime.Now.AddDays(7);

            await this.repositoryManager.UserRepository.UpdateAsync(_user);
            var accessToken = new JwtSecurityTokenHandler().WriteToken(tokenOptions);
            return new TokenDto(accessToken, refreshToken);
        }
        private static string GenerateRefreshToken()
        {
            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber);
            }
        }

        private ClaimsPrincipal GetPrincipalFromExpiredToken(string token) 
        { 
            var tokenValidationParameters = new TokenValidationParameters 
            { 
                ValidateAudience = true,
                ValidateIssuer = true, 
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration?.Value?.SecretKey!)),
                ValidateLifetime = true,
                ValidIssuer = configuration?.Value?.ValidIssuer,
                ValidAudience = configuration?.Value?.ValidAudience,
            };
            var tokenHandler = new JwtSecurityTokenHandler(); 
            SecurityToken securityToken; 
            var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out securityToken); 
            var jwtSecurityToken = securityToken as JwtSecurityToken; 
            if (jwtSecurityToken == null || !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase)) 
            { 
                throw new SecurityTokenException("Invalid token"); 
            } 
            return principal; 
        }
        private SigningCredentials GetSigningCredentials() 
        { 
            var key = Encoding.UTF8.GetBytes(configuration?.Value?.SecretKey!); 
            var secret = new SymmetricSecurityKey(key);
            return new SigningCredentials(secret, SecurityAlgorithms.HmacSha256);
        }

        private async Task<List<Claim>> GetClaims() 
        { 
            var claims = new List<Claim> 
            { 
                new Claim(ClaimTypes.Name, _user?.UserName!),
                new Claim(ClaimTypes.Email, _user?.Email!),
                new Claim("email", _user?.Email!)
            }; 
            var roles = await this.repositoryManager.UserRepository.GetRolesAsync(_user!); 
            foreach (var role in roles) 
            { 
                claims.Add(new Claim(ClaimTypes.Role, role)); 
            } 
            return claims; 
        }

        private JwtSecurityToken GenerateTokenOptions(SigningCredentials signingCredentials, List<Claim> claims) 
        { 
            var tokenOptions = new JwtSecurityToken
                (
                  issuer: configuration?.Value?.ValidIssuer,
                  audience: configuration?.Value?.ValidAudience,
                  claims: claims,
                  expires: DateTime.Now.AddMinutes(Convert.ToDouble(configuration?.Value?.Expires)),
                  signingCredentials: signingCredentials
                ); 
            return tokenOptions; 
        }

        public async Task<bool> ValidateUser(UserForAuthenticationDto userForAuth)
        {
            string userId = string.Empty;
            if (!memoryCache.TryGetValue(userForAuth.Email, out userId))
            {
                userId = await this.repositoryManager.UserRepository.GetUserIdByEmailAsync(userForAuth.Email!);
                memoryCache.Set(userForAuth.Email, userId);
            }

            _user = await this.repositoryManager.UserRepository.FindByIdAsync(userId);
            if(_user == null)
                throw new TaskManagementException(ExceptionEnum.UserNotFound,"User not exist!", [userForAuth.Email]);

            var result = (_user != null && await this.repositoryManager.UserRepository.CheckPasswordAsync(_user, userForAuth.Password!));

            return result;
        }
    }
}
