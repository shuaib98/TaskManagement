﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementSystem.Service.Contracts;
using TaskManagementSystem.Shared;
using TaskManagementSystem.Shared.DataTransferObject;

namespace TaskManagementSystem.Service.Decorator
{
    public class AuthenticationServiceDecorator(IAuthenticationService authenticationService, IMemoryCache cache) : IAuthenticationService
    {
        public async Task<TokenDto> CreateToken(bool populateExp)
        {
            return await authenticationService.CreateToken(populateExp);
        }

        public async Task<TokenDto> RefreshToken(TokenDto tokenDto)
        {
            return await authenticationService.RefreshToken(tokenDto);
        }

        public async Task<IdentityResult> RegisterUser(UserForRegistrationDto userForRegistration)
        {

           if (cache.TryGetValue<IdentityResult>(userForRegistration.Email!, out IdentityResult? identityResult))
            {
                return await Task.FromResult(identityResult!);
            }

            var result = await authenticationService.RegisterUser(userForRegistration);
            if (result.Succeeded)
            {
                cache.Set(userForRegistration.Email!, userForRegistration, TimeSpan.FromSeconds(300));
            }

            return result;
        }

        public async Task<bool> ValidateUser(UserForAuthenticationDto userForAuth)
        {
            if (cache.TryGetValue<bool>($"{userForAuth.Email}_isValid", out var isValid))
            {
                return await Task.FromResult(isValid);
            }

            var isValidUser= await authenticationService.ValidateUser(userForAuth);

            cache.Set($"{userForAuth.Email}_isValid", isValidUser, TimeSpan.FromSeconds(300));

            return isValidUser;
        }
    }
}
