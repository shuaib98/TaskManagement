﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace TaskManagementSystem.DataAccessLayer.Configuration
{
    public class RoleConfiguration : IEntityTypeConfiguration<IdentityRole>
    {
        public void Configure(EntityTypeBuilder<IdentityRole> builder)
        {
            builder.HasData(
                new IdentityRole {Id= "9C274F11-1CA3-4E78-B5BA-620FB7D31991", Name = "Manager", NormalizedName = "MANAGER" },
                new IdentityRole {Id= "30BCBE3E-9A1F-450E-AD27-D2F77FE94CFD", Name = "Administrator", NormalizedName = "ADMINISTRATOR" }
                );
        }
    }
}
