﻿using TaskManagementSystem.DataAccessLayer.Contracts;

namespace TaskManagementSystem.DataAccessLayer.Contexts
{
    public interface IRepositoryManager
    {
        Task SaveAsync();
        IBoardRepository BoardRepository { get; }
        IUserRepository UserRepository { get; }
        ISwimlaneRepository SwimlaneRepository { get; }
        ICardRepository CardRepository { get; }
    }
}
