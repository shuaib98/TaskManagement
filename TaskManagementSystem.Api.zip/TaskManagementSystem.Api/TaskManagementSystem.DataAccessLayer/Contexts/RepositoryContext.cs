﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using TaskManagementSystem.DataAccessLayer.Configuration;
using TaskManagementSystem.Entities.Models;


namespace TaskManagementSystem.DataAccessLayer.Contexts
{
    public class RepositoryContext : IdentityDbContext<User>
    {
        public RepositoryContext(DbContextOptions options) : base(options) { }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.ApplyConfiguration(new RoleConfiguration());
            builder.Entity<Board>()
                .HasMany(b => b.Swimlanes)
                .WithOne(s => s.Board)
                .HasForeignKey(s => s.BoardId)
                .OnDelete(DeleteBehavior.Cascade);

            // Board–User: Many-to-Many
            builder.Entity<Board>()
                .HasMany(b => b.Users)
                .WithMany(u => u.Boards)
                .UsingEntity(j => j.ToTable("BoardUsers"));

            // Swimlane–Card
            builder.Entity<Swimlane>()
                .HasMany(s => s.Cards)
                .WithOne(c => c.Swimlane)
                .HasForeignKey(c => c.SwimlaneId)
                .OnDelete(DeleteBehavior.Cascade);

            // Card–User
            builder.Entity<Card>()
                .HasOne(c => c.Assigne)
                .WithMany(u => u.Cards)
                .HasForeignKey(c => c.AssigneId)
                .OnDelete(DeleteBehavior.SetNull);

            builder.Entity<Card>()
                .HasMany(c => c.History)
                .WithOne(h => h.Card)
                .HasForeignKey(h => h.CardId)
                .OnDelete(DeleteBehavior.Cascade);

            // CardHistory–User: One CardHistory can have one ChangedBy (User)
            builder.Entity<CardHistory>()
                .HasOne(h => h.ChangedBy)
                .WithMany()
                .HasForeignKey(h => h.ChangedByUserId)
                .OnDelete(DeleteBehavior.SetNull);
        }
        public DbSet<Swimlane> Swimlanes { get; set; }
        public DbSet<Board> Boards { get; set; }
        public DbSet<Card> Cards { get; set; }
        public DbSet<CardHistory> CardHistories { get; set; }

    }
}
