﻿using Microsoft.EntityFrameworkCore;
using TaskManagementSystem.DataAccessLayer.Contexts;
using TaskManagementSystem.DataAccessLayer.Contracts;
using TaskManagementSystem.Entities.Models;

namespace TaskManagementSystem.DataAccessLayer.Repository
{
    public class BoardRepository : RepositoryBase<Board>,IBoardRepository
    {
        public BoardRepository(RepositoryContext repositoryContext) : base(repositoryContext)
        {
        }

        public async Task<Board> GetBoardById(string boardId)
        {
            return await FindByCondition(x => x.Id == boardId, false).FirstAsync();
        }

        public async Task<IEnumerable<Board>> GetAllBoards()
        {
            return await FindAll(false).ToListAsync();
        }

        public async Task CreateBoard(Board board)
        {
            await InsertAsync(board);
        }

        public async Task UpdateBoard(Board boardEntity)
        {
            await Task.Run(() => Update(boardEntity));
        }
        public async Task DeleteBoard(Board boardEntity)
        {
            await Task.Run(() => Delete(boardEntity));
        }
    }
}
