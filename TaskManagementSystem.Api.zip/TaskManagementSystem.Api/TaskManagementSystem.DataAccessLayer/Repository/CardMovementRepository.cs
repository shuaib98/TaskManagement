﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementSystem.DataAccessLayer.Contexts;
using TaskManagementSystem.Entities.Models;

namespace TaskManagementSystem.DataAccessLayer.Repository
{
    public class CardMovementRepository(RepositoryContext repositoryContext) : RepositoryBase<CardMovement>(repositoryContext)
    {
    }
}
