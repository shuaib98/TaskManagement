﻿using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using TaskManagementSystem.DataAccessLayer.Contexts;

namespace TaskManagementSystem.DataAccessLayer.Repository
{
    public class RepositoryBase<T> : IRepository<T> where T : class
    {
        protected RepositoryContext RepositoryContext;

        public RepositoryBase(RepositoryContext repositoryContext)
            => RepositoryContext = repositoryContext;

        public IQueryable<T> FindAll(bool trackChanges) =>
            !trackChanges ?
              RepositoryContext.Set<T>()
                .AsNoTracking() :
              RepositoryContext.Set<T>();

        public IQueryable<T> FindByCondition(Expression<Func<T, bool>> expression,
        bool trackChanges) =>
            !trackChanges ?
              RepositoryContext.Set<T>()
                .Where(expression)
                .AsNoTracking() :
              RepositoryContext.Set<T>()
                .Where(expression);

        public async Task InsertAsync(T entity) => await RepositoryContext.Set<T>().AddAsync(entity);
        public async Task InsertRangeAsync(IEnumerable<T> entities) => await RepositoryContext.Set<T>().AddRangeAsync(entities);

        public void Update(T entity) => RepositoryContext.Set<T>().Update(entity);
        public void UpdateRange(IEnumerable<T> entities) => RepositoryContext.Set<T>().UpdateRange(entities);

        public void Delete(T entity) => RepositoryContext.Set<T>().Remove(entity);
        public void DeleteRange(IEnumerable<T> entities) => RepositoryContext.Set<T>().RemoveRange(entities);
    }
}
