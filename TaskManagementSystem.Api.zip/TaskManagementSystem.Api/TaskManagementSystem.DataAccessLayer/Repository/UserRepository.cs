﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using TaskManagementSystem.DataAccessLayer.Contexts;
using TaskManagementSystem.DataAccessLayer.Contracts;
using TaskManagementSystem.Entities.Models;

namespace TaskManagementSystem.DataAccessLayer.Repository
{
    public class UserRepository(UserManager<User> userManager) : IUserRepository
    {
        public async Task<User?> GetUserByEmail(string email)
        {
            return await userManager.FindByEmailAsync(email);
        }

        public async Task<string> GetUserIdByEmailAsync(string email)
        {
            return await userManager.Users
                .Where(u => u.Email == email)
                .Select(u =>  u.Id )
                .SingleOrDefaultAsync()??string.Empty;
        }

        public async Task<User?> FindByIdAsync(string userId)
        {
            return await userManager.FindByIdAsync(userId);
        }

        public async Task<User?> FindByNameAsync(string userId)
        {
            return await userManager.FindByNameAsync(userId);
        }

        public async Task<IdentityResult> CreateAsync(User user,string password)
        {
            return await userManager.CreateAsync(user, password);
        }

        public async Task<IdentityResult> UpdateAsync(User user)
        {
            return await userManager.UpdateAsync(user);
        }

        public async Task<IdentityResult> AddToRolesAsync(User user, IEnumerable<string> roles)
        {
            return await userManager.AddToRolesAsync(user, roles);
        }
        public async Task<IList<string>> GetRolesAsync(User user)
        {
            return await userManager.GetRolesAsync(user);
        }
        public async Task<bool> CheckPasswordAsync(User user, string password)
        {
            return await userManager.CheckPasswordAsync(user, password);
        }
    }
}
