﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System.Data;
using TaskManagementSystem.DataAccessLayer.Contexts;
using TaskManagementSystem.DataAccessLayer.Contracts;

namespace TaskManagementSystem.DataAccessLayer.Repository
{
    public class UnitOfWork(RepositoryContext dbContext) : IUnitOfWork
    {
        public RepositoryContext DbContext { get; private set; } = dbContext;
        private IDictionary<string, object> repositories { get; }
        private IDbContextTransaction transaction;
        private IsolationLevel? isolationLevel;

        private bool disposed = false; // To detect redundant calls

        public async Task BeginTransaction()
        {
            if (this.transaction == null)
            {
                this.transaction = this.isolationLevel.HasValue
                    ? await DbContext.Database.BeginTransactionAsync(this.isolationLevel.Value)
                    : await DbContext.Database.BeginTransactionAsync();
            }
        }

        public async Task CommitTransaction()
        {
            await this.DbContext.SaveChangesAsync();

            if (this.transaction == null)
            {
                return;
            }
            await this.transaction.CommitAsync();
            await this.transaction.DisposeAsync();
        }

        public IRepository<TEntity> Repository<TEntity>() where TEntity : class
        {
            var type = typeof(TEntity).Name;
            lock (repositories)
            {
                if (repositories.ContainsKey(type))
                {
                    return (IRepository<TEntity>)repositories[type];
                }

                var repository = new RepositoryBase<TEntity>(DbContext);
                repositories.Add(type, repository);
                return repository;
            }
        }

        public async Task RollbackTransaction()
        {
            if (this.transaction == null) return;

            await this.transaction.RollbackAsync();
            await this.transaction.DisposeAsync();
        }

        public async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            return await DbContext.SaveChangesAsync(cancellationToken);
        }

        public void SetIsolationLevel(IsolationLevel isolationLevel)
        {
            this.isolationLevel = isolationLevel;
        }
       
    }
}
