﻿using Microsoft.EntityFrameworkCore;
using TaskManagementSystem.DataAccessLayer.Contexts;
using TaskManagementSystem.DataAccessLayer.Contracts;
using TaskManagementSystem.Entities.Models;

namespace TaskManagementSystem.DataAccessLayer.Repository
{
    public class CardRepository(RepositoryContext repositoryContext) : RepositoryBase<Card>(repositoryContext), ICardRepository
    {
        public async Task<Card?> GetCardByIdAsync(string cardId)
        {
            return await FindByCondition(c => c.Id.Equals(cardId), false).SingleOrDefaultAsync();
        }
        public async Task<IEnumerable<Card>> GetCardsBySwimlaneIdAsync(string swimlaneId)
        {
            return await FindByCondition(c => c.SwimlaneId.Equals(swimlaneId), false).ToListAsync();
        }
        public async Task<IEnumerable<Card>> GetAllCardsAsync()
        {
            return await FindAll(false).ToListAsync();
        }

        public async Task InsertCardAsync(Card card)
        {
            await InsertAsync(card);
        }

        public void UpdateCardsSwimlaneAndOrder(IEnumerable<Card> cards)
        {
            UpdateRange(cards);
        }
    }
}
