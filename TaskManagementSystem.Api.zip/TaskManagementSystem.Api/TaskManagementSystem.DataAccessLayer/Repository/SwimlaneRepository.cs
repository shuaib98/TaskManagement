﻿using Microsoft.EntityFrameworkCore;
using TaskManagementSystem.DataAccessLayer.Contexts;
using TaskManagementSystem.DataAccessLayer.Contracts;
using TaskManagementSystem.Entities.Models;

namespace TaskManagementSystem.DataAccessLayer.Repository
{
    public class SwimlaneRepository(RepositoryContext repositoryContext) : RepositoryBase<Swimlane>(repositoryContext), ISwimlaneRepository
    {
        private readonly RepositoryContext repositoryContext = repositoryContext;

        public async Task CreateSwimlane(Swimlane swimlane)
        {
            await InsertAsync(swimlane);
        }

        public async Task<IEnumerable<Board>> GetSwimlineByBoardId(string boardId)
        {
            var query= await repositoryContext.Boards
                .AsNoTracking()
                .Include(s => s.Swimlanes)
                .ThenInclude(c => c.Cards)
                .AsSplitQuery()
                .Where(s => s.Id == boardId).ToListAsync();


            return query;
            //return await FindByCondition(x => x.BoardId.Equals(boardId), false).ToListAsync();
        }

    }
}
