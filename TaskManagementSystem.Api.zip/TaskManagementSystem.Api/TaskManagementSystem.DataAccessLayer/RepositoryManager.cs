﻿using Microsoft.AspNetCore.Identity;
using TaskManagementSystem.DataAccessLayer.Contexts;
using TaskManagementSystem.DataAccessLayer.Contracts;
using TaskManagementSystem.DataAccessLayer.Repository;
using TaskManagementSystem.Entities.Models;

namespace TaskManagementSystem.DataAccessLayer
{
    public class RepositoryManager : IRepositoryManager
    {
        private readonly Lazy<IBoardRepository> _boardRepository;
        private readonly Lazy<IUserRepository> _userRepository;
        private readonly Lazy<ISwimlaneRepository> _swimlaneRepository;
        private readonly Lazy<ICardRepository> _cardRepository;
        private readonly RepositoryContext repositoryContext;

        public RepositoryManager(RepositoryContext repositoryContext,IUnitOfWork unitOfWork, UserManager<User> userManager)
        {
            this._boardRepository = new Lazy<IBoardRepository>(()=>new BoardRepository(repositoryContext));
            this._userRepository=new Lazy<IUserRepository>(() => new UserRepository(userManager));
            this._swimlaneRepository = new Lazy<ISwimlaneRepository>(() => new SwimlaneRepository(repositoryContext));
            this._cardRepository = new Lazy<ICardRepository>(() => new CardRepository(repositoryContext));
            this.repositoryContext = repositoryContext;
        }
        public IBoardRepository BoardRepository => this._boardRepository.Value;
        public IUserRepository UserRepository => this._userRepository.Value;
        public ISwimlaneRepository SwimlaneRepository => this._swimlaneRepository.Value;
        public ICardRepository CardRepository => this._cardRepository.Value;

        public async Task SaveAsync() => await repositoryContext.SaveChangesAsync();
    }
}
