﻿using Microsoft.AspNetCore.Identity;
using TaskManagementSystem.Entities.Models;

namespace TaskManagementSystem.DataAccessLayer.Contracts
{
    public interface IUserRepository
    {
        Task<User?> GetUserByEmail(string email);
        Task<string> GetUserIdByEmailAsync(string email);
        Task<User?> FindByIdAsync(string userId);
        Task<IdentityResult> CreateAsync(User user, string password);
        Task<IdentityResult> UpdateAsync(User user);
        Task<IdentityResult> AddToRolesAsync(User user, IEnumerable<string> roles);
        Task<IList<string>> GetRolesAsync(User user);
        Task<User?> FindByNameAsync(string userId);
        Task<bool> CheckPasswordAsync(User user, string password);
    }
}
