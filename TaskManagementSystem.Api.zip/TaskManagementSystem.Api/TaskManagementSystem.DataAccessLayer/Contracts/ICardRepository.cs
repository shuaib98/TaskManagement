﻿using TaskManagementSystem.Entities.Models;

namespace TaskManagementSystem.DataAccessLayer.Contracts
{
    public interface ICardRepository
    {
        Task<Card?> GetCardByIdAsync(string cardId);
        Task<IEnumerable<Card>> GetCardsBySwimlaneIdAsync(string swimlaneId);
        Task<IEnumerable<Card>> GetAllCardsAsync();
        Task InsertCardAsync(Card card);
        void UpdateCardsSwimlaneAndOrder(IEnumerable<Card> cards);
    }
}
