﻿using TaskManagementSystem.Entities.Models;

namespace TaskManagementSystem.DataAccessLayer.Contracts
{
    public interface ISwimlaneRepository
    {
        Task CreateSwimlane(Swimlane swimlane);
        Task<IEnumerable<Board>> GetSwimlineByBoardId(string boardId);
    }
}
