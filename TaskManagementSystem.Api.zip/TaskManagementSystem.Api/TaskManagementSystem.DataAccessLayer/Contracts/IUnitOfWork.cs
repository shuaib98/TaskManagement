﻿using System.Data;
using TaskManagementSystem.DataAccessLayer.Contexts;

namespace TaskManagementSystem.DataAccessLayer.Contracts
{
    public interface IUnitOfWork
    {
        RepositoryContext DbContext { get; }
        IRepository<T> Repository<T>() where T : class;
        Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
        Task BeginTransaction();
        Task CommitTransaction();
        Task RollbackTransaction();
        void SetIsolationLevel(IsolationLevel isolationLevel);
    }
}
