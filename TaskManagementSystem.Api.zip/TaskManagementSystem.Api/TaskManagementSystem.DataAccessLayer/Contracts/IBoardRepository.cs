﻿using TaskManagementSystem.Entities.Models;

namespace TaskManagementSystem.DataAccessLayer.Contracts
{
    public interface IBoardRepository
    {
        Task<Board> GetBoardById(string boardId);
        Task CreateBoard(Board board);
        Task<IEnumerable<Board>> GetAllBoards();
        Task UpdateBoard(Board boardEntity);
        Task DeleteBoard(Board boardEntity);
    }
}
