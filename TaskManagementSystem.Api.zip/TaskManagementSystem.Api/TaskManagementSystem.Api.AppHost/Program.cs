var builder = DistributedApplication.CreateBuilder(args);

var cache = builder.AddRedis("cache")
    .WithRedisCommander();

var api=builder.AddProject<Projects.TaskManagementSystem_Api>("taskmanagementsystem-api")
    .WithReference(cache); 

builder.AddNpmApp("TaskManagement", "../../TaskManagementSystem")
    .WithReference(api)
    .WithHttpEndpoint(env: "PORT")
    .WithExternalHttpEndpoints();

builder.Build().Run();
