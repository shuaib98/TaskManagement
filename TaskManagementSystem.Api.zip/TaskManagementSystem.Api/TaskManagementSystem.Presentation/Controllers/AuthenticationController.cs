﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TaskManagementSystem.Presentation.ActionFilters;
using TaskManagementSystem.Service.Contracts;
using TaskManagementSystem.Shared;
using TaskManagementSystem.Shared.DataTransferObject;

namespace TaskManagementSystem.Presentation.Controllers
{
    [Route("api/authentication")]
    [ApiController]
    public class AuthenticationController(IServiceManager service,ILogger<AuthenticationController> logger) : ControllerBase
    {
        private readonly IServiceManager _service = service;

        [HttpGet(Name = "GetHealth")]
        public  IActionResult GetHealth()
        {
            return Ok("Service is running");
        }

        [HttpPost("register")]

        public async Task<IActionResult> RegisterUser([FromBody] UserForRegistrationDto userForRegistration)
        {
            var result = await _service.AuthenticationService.RegisterUser(userForRegistration);
            if (!result.Succeeded) 
            {
                foreach (var error in result.Errors) 
                { 
                    ModelState.TryAddModelError(error.Code, error.Description); 
                } 
                return BadRequest(ModelState); 
            }
            return StatusCode(201);
        }

        [HttpPost("login")]

        public async Task<IActionResult> Authenticate([FromBody] UserForAuthenticationDto user) 
        {
            logger.LogInformation($"Authentication Start for user {user.Email}");
            if (!await _service.AuthenticationService.ValidateUser(user)) 
                return Unauthorized();

            var tokenDto = await _service.AuthenticationService.CreateToken(true); 
            logger.LogInformation($"Authentication successful for user {user.Email}");
            return Ok(tokenDto);
        }
    }
}
