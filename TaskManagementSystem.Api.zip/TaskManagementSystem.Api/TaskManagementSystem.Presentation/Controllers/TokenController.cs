﻿using Microsoft.AspNetCore.Mvc;
using TaskManagementSystem.Presentation.ActionFilters;
using TaskManagementSystem.Service.Contracts;
using TaskManagementSystem.Shared.DataTransferObject;

namespace TaskManagementSystem.Presentation.Controllers
{
    [Route("api/token")]
    [ApiController]
    public class TokenController: ControllerBase
    {
        private readonly IServiceManager _service; 
        public TokenController(IServiceManager service) => _service = service;

        [HttpPost("refresh")]
        [ServiceFilter(typeof(ValidationFilter))] 
        public async Task<IActionResult> Refresh([FromBody] TokenDto tokenDto) 
        { 
            var tokenDtoToReturn = await _service.AuthenticationService.RefreshToken(tokenDto); 
            return Ok(tokenDtoToReturn); 
        }
    }
}
