﻿// Ignore Spelling: Swimlane

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskManagementSystem.Service.Contracts;
using TaskManagementSystem.Shared.DataTransferObject;

namespace TaskManagementSystem.Presentation.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class SwimlaneController(IServiceManager service) : ControllerBase
    {
        private readonly IServiceManager service = service;

        [HttpPost()]
        public async Task<IActionResult> CreateSwimlane([FromBody] CreateSwimlaneDto swimlane)
        {
            var result = await service.SwimlaneService.CreateSwimlane(swimlane);
            return Ok(result);
        }

        [HttpGet("{boardId}",Name = "GetSwimlineByBoardId")]
        public async Task<IActionResult> GetSwimlineByBoardId(string boardId)
        {
            var result = await service.SwimlaneService.GetSwimlineByBoardId(boardId);
            return Ok(result);
        }
    }
}
