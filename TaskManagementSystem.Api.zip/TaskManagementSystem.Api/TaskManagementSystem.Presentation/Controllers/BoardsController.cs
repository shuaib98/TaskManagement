﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskManagementSystem.Service.Contracts;
using TaskManagementSystem.Shared.DataTransferObject;

namespace TaskManagementSystem.Presentation.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class BoardsController(IServiceManager service):ControllerBase
    {
        private readonly IServiceManager service = service;

        [HttpGet("health")]
        public string Get()
        {
            return "connected";
        }

        [HttpGet]
        public async Task<IActionResult> GetAllBoards()
        {
            var result=await service.BoardService.GetAllBoards();
            return Ok(result);
        }

        [HttpPost("create")]
        public async Task<IActionResult> CreateBoard([FromBody] CreateBoardDto createBoard)
        {
            var emailId = User.FindAll(x=>x.Type.Contains("emailaddress")).First()?.Value;
            var result = await service.BoardService.CreateBoard(createBoard, emailId!);
            return Ok(result);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateBoard([FromBody] CreateBoardDto createBoard)
        {
            var result = await service.BoardService.UpdateBoard(createBoard);
            return Ok(result);
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteBoard([FromQuery] string boardId)
        {
            await service.BoardService.DeleteBoard(boardId);
            return Ok();
        }

        [HttpGet("board-by-id")]
        public async Task<IActionResult> GetBoardById([FromQuery] string boardId)
        {
            var result = await service.BoardService.GetBoardById(boardId);
            return Ok(result);
        }
    }
}
