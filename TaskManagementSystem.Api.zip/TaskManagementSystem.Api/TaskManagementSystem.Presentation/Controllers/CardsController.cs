﻿using Microsoft.AspNetCore.Mvc;
using TaskManagementSystem.Presentation.ActionFilters;
using TaskManagementSystem.Service.Contracts;
using TaskManagementSystem.Shared.DataTransferObject;

namespace TaskManagementSystem.Presentation.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CardsController(IServiceManager serviceManager) : ControllerBase
    {
        private readonly IServiceManager serviceManager = serviceManager;

        [HttpPost()]
        [ServiceFilter(typeof(ValidationFilter))]
        public async Task<IActionResult> CreateCard([FromBody] CreateCardDto card)
        {
            var result = await serviceManager.CardService.InsertCardAsync(card);
            return Ok(result);
        }

        [HttpPatch()]
        public async Task<IActionResult> UpdateCardSwimlane([FromBody] IEnumerable<CardDto> cardSwimlane)
        {
            var result= await serviceManager.CardService.UpdateCardSwimlaneAsync(cardSwimlane);
            return Ok(result);
        }
    }
}
