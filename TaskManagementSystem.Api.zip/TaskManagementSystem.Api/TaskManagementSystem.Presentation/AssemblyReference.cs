﻿namespace TaskManagementSystem.Presentation
{
    public static class AssemblyReference { }
}
