﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace TaskManagementSystem.Common.Helpers
{
    public static class ResourceHelper
    {
        public static string GetTranslatedText(string key, string languageCode)
        {
            if (string.IsNullOrWhiteSpace(key))
                throw new ArgumentException("The key can't be null or empty", nameof(key));

            if (string.IsNullOrWhiteSpace(languageCode))
                throw new ArgumentException("The language code cn't be null or empty", nameof(languageCode));

            try
            {
                var culture = new CultureInfo(languageCode);
                var resourceManager = new ResourceManager("Pac.Services.Resources.PacResources", typeof(ResourceHelper).Assembly);
                var translatedText = resourceManager.GetString(key, culture);

                if (string.IsNullOrEmpty(translatedText))
                    throw new MissingManifestResourceException($"The key {key} doesn't exists for the code {languageCode}.");

                return translatedText;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Error retrieving the resource : {ex.Message}", ex);
            }
        }
    }
}
