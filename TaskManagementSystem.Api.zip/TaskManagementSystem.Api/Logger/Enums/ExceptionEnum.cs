﻿
namespace TaskManagementSystem.Common.Enums;

public enum ExceptionEnum
{
    BoardNotFound = 101,
    UserNotFound = 102
}

