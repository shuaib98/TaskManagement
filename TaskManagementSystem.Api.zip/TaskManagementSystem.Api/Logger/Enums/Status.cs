﻿public enum Status
{
    Ok,
    Warning,
    Error
}