﻿using TaskManagementSystem.Common.Enums;

namespace TaskManagementSystem.Common;

public class TaskManagementException : Exception
{
    public ExceptionEnum ErrorType { protected set; get; }

    public string Details { protected set; get; }

    public string[] Args { set; get; }
    public TaskManagementException(ExceptionEnum errorType, string message,  string[] args=null, string details = "", Exception innerException = null)
        : base(message, innerException)
    {
        ErrorType = errorType;
        Details = details;
        Args = args ?? Array.Empty<string>();
    }
}

